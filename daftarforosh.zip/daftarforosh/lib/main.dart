import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DaftarForoshApp());
}

class DaftarForoshApp extends StatelessWidget {
  const DaftarForoshApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دفترفروش',
      locale: const Locale('fa'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFD9A441)),
        scaffoldBackgroundColor: const Color(0xFF15161A),
        brightness: Brightness.dark,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF202126),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF35363D)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF35363D)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFD9A441), width: 1.5),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class SaleRecord {
  int quantity;
  int price;

  SaleRecord({required this.quantity, required this.price});

  Map<String, dynamic> toJson() => {'quantity': quantity, 'price': price};

  factory SaleRecord.fromJson(Map<String, dynamic> json) => SaleRecord(
        quantity: (json['quantity'] as num?)?.toInt() ?? 0,
        price: (json['price'] as num?)?.toInt() ?? 0,
      );
}

class Product {
  String id;
  String name;
  int unitPrice;
  int purchaseQty;
  Map<String, SaleRecord> sales;

  Product({
    required this.id,
    required this.name,
    required this.unitPrice,
    required this.purchaseQty,
    Map<String, SaleRecord>? sales,
  }) : sales = sales ?? {};

  int get soldQty => sales.values.fold(0, (sum, s) => sum + s.quantity);
  int get inventory => purchaseQty - soldQty;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'unitPrice': unitPrice,
        'purchaseQty': purchaseQty,
        'sales': sales.map((k, v) => MapEntry(k, v.toJson())),
      };

  factory Product.fromJson(Map<String, dynamic> json) {
    final rawSales = (json['sales'] as Map?)?.cast<String, dynamic>() ?? {};
    return Product(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      unitPrice: (json['unitPrice'] as num?)?.toInt() ?? 0,
      purchaseQty: (json['purchaseQty'] as num?)?.toInt() ?? 0,
      sales: rawSales.map(
        (key, value) => MapEntry(
          key,
          SaleRecord.fromJson(Map<String, dynamic>.from(value as Map)),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _storageKey = 'daftarforosh_data_v1';

  List<Product> products = [];
  List<String> dates = [];
  bool loading = true;
  String search = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw != null && raw.isNotEmpty) {
      try {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        products = ((data['products'] as List?) ?? [])
            .map((e) => Product.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        dates = ((data['dates'] as List?) ?? []).map((e) => e.toString()).toList();
      } catch (_) {
        products = [];
        dates = [];
      }
    }
    dates.sort(compareDates);
    if (mounted) setState(() => loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _storageKey,
      jsonEncode({
        'products': products.map((p) => p.toJson()).toList(),
        'dates': dates,
      }),
    );
  }

  List<Product> get visibleProducts {
    final q = normalizeDigits(search).trim().toLowerCase();
    if (q.isEmpty) return products;
    return products.where((p) => p.name.toLowerCase().contains(q)).toList();
  }

  Future<void> _addProduct() async {
    final result = await showProductDialog(context);
    if (result == null) return;
    setState(() => products.add(result));
    await _save();
  }

  Future<void> _editProduct(Product product) async {
    final edited = await showProductDialog(context, product: product);
    if (edited == null) return;
    setState(() {
      product.name = edited.name;
      product.unitPrice = edited.unitPrice;
      product.purchaseQty = edited.purchaseQty;
    });
    await _save();
  }

  Future<void> _deleteProduct(Product product) async {
    final ok = await confirmDialog(
      context,
      title: 'حذف کالا',
      message: 'آیا مطمئنی می‌خواهی این کالا حذف شود؟',
      confirmText: 'حذف',
    );
    if (!ok) return;
    setState(() => products.removeWhere((p) => p.id == product.id));
    await _save();
  }

  Future<void> _addDate() async {
    final date = await showDateInputDialog(context, title: 'انتخاب تاریخ');
    if (date == null) return;
    if (dates.contains(date)) {
      showSnack(context, 'این تاریخ قبلاً اضافه شده است.');
      return;
    }
    setState(() {
      dates.add(date);
      dates.sort(compareDates);
    });
    await _save();
  }

  Future<void> _setSale(Product product, String date, int quantity) async {
    if (quantity < 0) return;
    final existing = product.sales[date];
    final previousQty = existing?.quantity ?? 0;
    final availableForThisEdit = product.inventory + previousQty;
    if (quantity > availableForThisEdit) {
      showSnack(context, 'موجودی کافی نیست. موجودی قابل فروش: ${formatNumber(availableForThisEdit)}');
      return;
    }
    if (quantity == 0) {
      product.sales.remove(date);
    } else {
      // The current price is captured only the first time this date is sold.
      product.sales[date] = existing ?? SaleRecord(quantity: quantity, price: product.unitPrice);
      product.sales[date]!.quantity = quantity;
    }
    await _save();
    if (mounted) setState(() {});
  }

  Future<void> _showDayReport() async {
    final date = await showDateInputDialog(context, title: 'گزارش فروش کدام روز را می‌خواهی؟');
    if (date == null) return;
    await _showReportDialog(date: date);
  }

  Future<void> _showRangeReport() async {
    final from = await showDateInputDialog(context, title: 'از چه تاریخی؟');
    if (from == null) return;
    final to = await showDateInputDialog(context, title: 'تا چه تاریخی؟');
    if (to == null) return;
    if (compareDates(from, to) > 0) {
      showSnack(context, 'تاریخ شروع باید قبل از تاریخ پایان باشد.');
      return;
    }
    await _showReportDialog(from: from, to: to);
  }

  Future<void> _showReportDialog({String? date, String? from, String? to}) async {
    final rows = <ReportRow>[];
    for (final p in products) {
      int qty = 0;
      int amount = 0;
      int? singlePrice;
      if (date != null) {
        final s = p.sales[date];
        if (s != null && s.quantity > 0) {
          qty = s.quantity;
          amount = s.quantity * s.price;
          singlePrice = s.price;
        }
      } else {
        for (final entry in p.sales.entries) {
          if (compareDates(entry.key, from!) >= 0 && compareDates(entry.key, to!) <= 0) {
            qty += entry.value.quantity;
            amount += entry.value.quantity * entry.value.price;
          }
        }
      }
      if (qty > 0) {
        rows.add(ReportRow(p.name, qty, amount, singlePrice));
      }
    }

    final totalQty = rows.fold(0, (sum, r) => sum + r.quantity);
    final totalAmount = rows.fold(0, (sum, r) => sum + r.amount);

    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(date != null ? 'گزارش فروش $date' : 'گزارش از $from تا $to'),
          content: SizedBox(
            width: 500,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (rows.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 28),
                      child: Center(child: Text('در این بازه فروشی ثبت نشده است.')),
                    )
                  else
                    ...rows.map(
                      (r) => Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              const SizedBox(height: 6),
                              if (date != null)
                                Text('${formatNumber(r.quantity)} عدد × ${formatNumber(r.price!)} = ${formatNumber(r.amount)} تومان'),
                              if (date == null)
                                Text('${formatNumber(r.quantity)} عدد — مبلغ کل: ${formatNumber(r.amount)} تومان'),
                            ],
                          ),
                        ),
                      ),
                    ),
                  const Divider(height: 28),
                  Text('تعداد کل فروش: ${formatNumber(totalQty)} عدد', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('مبلغ کل فروش: ${formatNumber(totalAmount)} تومان', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('بستن'))],
        ),
      ),
    );
  }

  Future<void> _clearAll() async {
    final first = await confirmDialog(
      context,
      title: '⚠️ پاک کردن همه',
      message: 'مطمئنی می‌خواهی همه اطلاعات پاک شود؟',
      confirmText: 'ادامه',
    );
    if (!first) return;
    final code = (1000 + Random().nextInt(9000)).toString();
    final controller = TextEditingController();
    final entered = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تأیید نهایی'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('برای پاک کردن همه اطلاعات، این کد را وارد کن:'),
              const SizedBox(height: 14),
              Center(child: Text(code, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, letterSpacing: 6))),
              const SizedBox(height: 14),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                decoration: const InputDecoration(hintText: 'کد ۴ رقمی'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, normalizeDigits(controller.text) == code), child: const Text('تأیید')),
          ],
        ),
      ),
    );
    controller.dispose();
    if (entered != true) {
      showSnack(context, 'کد اشتباه بود. اطلاعات پاک نشد.');
      return;
    }
    setState(() {
      products.clear();
      dates.clear();
    });
    await _save();
    showSnack(context, 'همه اطلاعات پاک شد.');
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('دفترفروش', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: Colors.transparent,
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
            children: [
              TextField(
                onChanged: (v) => setState(() => search = v),
                decoration: const InputDecoration(
                  hintText: '🔎 جست‌وجوی کالا...',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _addProduct,
                icon: const Icon(Icons.add),
                label: const Text('افزودن کالای جدید'),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              ),
              const SizedBox(height: 18),
              _buildDateSection(),
              const SizedBox(height: 18),
              _buildProductsSection(),
              const SizedBox(height: 18),
              _buildSalesSections(),
              const SizedBox(height: 22),
              const Text('📊 گزارش‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: _showDayReport,
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                child: const Text('گزارش فروش یک روز'),
              ),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: _showRangeReport,
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                child: const Text('گزارش از این تاریخ تا این تاریخ'),
              ),
              const SizedBox(height: 26),
              Center(
                child: OutlinedButton.icon(
                  onPressed: _clearAll,
                  icon: const Icon(Icons.delete_forever, size: 18),
                  label: const Text('پاک کردن همه'),
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red.shade300),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDateSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('📅 ثبت فروش روزانه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: Text(
                dates.isEmpty ? 'هنوز تاریخی ثبت نشده.' : 'تاریخ‌های فروش: ${dates.join('، ')}',
                style: TextStyle(color: Colors.grey.shade300),
              ),
            ),
            FilledButton.icon(onPressed: _addDate, icon: const Icon(Icons.calendar_month), label: const Text('انتخاب تاریخ')),
          ],
        ),
      ],
    );
  }

  Widget _buildProductsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('📦 کالاها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (visibleProducts.isEmpty)
          Container(
            padding: const EdgeInsets.all(22),
            decoration: boxDecoration(),
            child: Center(child: Text(search.isEmpty ? 'هنوز کالایی اضافه نشده. با دکمه بالا شروع کن.' : 'کالایی پیدا نشد.')),
          )
        else
          Container(
            decoration: boxDecoration(),
            child: Column(
              children: [
                _tableHeader(),
                ...visibleProducts.map(_productRow),
              ],
            ),
          ),
      ],
    );
  }

  Widget _tableHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
      decoration: const BoxDecoration(color: Color(0xFF24252B)),
      child: Row(
        children: const [
          Expanded(flex: 3, child: Text('نام کالا', textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text('قیمت واحد', textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text('تعداد خرید', textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text('موجودی', textAlign: TextAlign.center)),
          SizedBox(width: 42),
        ],
      ),
    );
  }

  Widget _productRow(Product p) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFF303138)))),
      child: Row(
        children: [
          Expanded(flex: 3, child: Text(p.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis)),
          Expanded(flex: 2, child: Text(formatNumber(p.unitPrice), textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text(formatNumber(p.purchaseQty), textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text(formatNumber(p.inventory), textAlign: TextAlign.center, style: TextStyle(color: p.inventory < 0 ? Colors.red : null))),
          SizedBox(
            width: 42,
            child: PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') _editProduct(p);
                if (v == 'delete') _deleteProduct(p);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('ویرایش کالا')),
                PopupMenuItem(value: 'delete', child: Text('حذف کالا')),
              ],
              icon: const Icon(Icons.more_vert),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSalesSections() {
    if (dates.isEmpty || visibleProducts.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: boxDecoration(),
        child: const Text('برای ثبت فروش، ابتدا کالا و حداقل یک تاریخ اضافه کن.'),
      );
    }

    final groups = <List<String>>[];
    for (var i = 0; i < dates.length; i += 3) {
      groups.add(dates.sublist(i, min(i + 3, dates.length)));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('🧾 فروش روزانه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...groups.asMap().entries.map((entry) => _salesGroup(entry.key + 1, entry.value)),
      ],
    );
  }

  Widget _salesGroup(int groupNumber, List<String> groupDates) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: Text('گروه $groupNumber', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Table(
              columnWidths: {
                0: const FlexColumnWidth(1.6),
                for (var i = 1; i <= groupDates.length; i++) i: const FlexColumnWidth(1),
              },
              children: [
                TableRow(
                  decoration: const BoxDecoration(color: Color(0xFF24252B)),
                  children: [
                    const Padding(padding: EdgeInsets.all(8), child: Text('کالا', textAlign: TextAlign.center)),
                    ...groupDates.map((d) => Padding(padding: const EdgeInsets.all(8), child: Text('فروش $d', textAlign: TextAlign.center))),
                  ],
                ),
                ...visibleProducts.map(
                  (p) => TableRow(
                    children: [
                      Padding(padding: const EdgeInsets.all(8), child: Text(p.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis)),
                      ...groupDates.map((d) => _saleCell(p, d)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _saleCell(Product p, String date) {
    return SaleCell(
      key: ValueKey('${p.id}-$date'),
      value: p.sales[date]?.quantity ?? 0,
      onSave: (quantity) => _setSale(p, date, quantity),
    );
  }
}


class SaleCell extends StatefulWidget {
  final int value;
  final ValueChanged<int> onSave;

  const SaleCell({super.key, required this.value, required this.onSave});

  @override
  State<SaleCell> createState() => _SaleCellState();
}

class _SaleCellState extends State<SaleCell> {
  late final TextEditingController controller;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.value == 0 ? '' : widget.value.toString());
  }

  @override
  void didUpdateWidget(covariant SaleCell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value && controller.text != (widget.value == 0 ? '' : widget.value.toString())) {
      controller.text = widget.value == 0 ? '' : widget.value.toString();
    }
  }

  void save() {
    widget.onSave(parseInt(controller.text) ?? 0);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        decoration: const InputDecoration(
          hintText: '۰',
          contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 10),
        ),
        onSubmitted: (_) => save(),
        onTapOutside: (_) => save(),
      ),
    );
  }
}

class ReportRow {
  final String name;
  final int quantity;
  final int amount;
  final int? price;

  ReportRow(this.name, this.quantity, this.amount, this.price);
}

BoxDecoration boxDecoration() => BoxDecoration(
      color: const Color(0xFF1C1D22),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFF34353C)),
    );

String normalizeDigits(String input) {
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var out = input;
  for (var i = 0; i < 10; i++) {
    out = out.replaceAll(fa[i], i.toString()).replaceAll(ar[i], i.toString());
  }
  return out;
}

String formatNumber(int value) {
  final negative = value < 0;
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(',');
    buffer.write(digits[i]);
  }
  return '${negative ? '-' : ''}$buffer';
}

int compareDates(String a, String b) {
  final aa = parseDate(a);
  final bb = parseDate(b);
  final av = aa == null ? 999999 : aa.$1 * 100 + aa.$2;
  final bv = bb == null ? 999999 : bb.$1 * 100 + bb.$2;
  return av.compareTo(bv);
}

(int, int)? parseDate(String raw) {
  final s = normalizeDigits(raw).trim();
  final parts = s.split('.');
  if (parts.length != 2) return null;
  final month = int.tryParse(parts[0]);
  final day = int.tryParse(parts[1]);
  if (month == null || day == null || month < 1 || month > 12 || day < 1 || day > 31) return null;
  return (month, day);
}

Future<Product?> showProductDialog(BuildContext context, {Product? product}) async {
  final name = TextEditingController(text: product?.name ?? '');
  final price = TextEditingController(text: product?.unitPrice.toString() ?? '');
  final purchase = TextEditingController(text: product?.purchaseQty.toString() ?? '');
  final formKey = GlobalKey<FormState>();

  final result = await showDialog<Product>(
    context: context,
    builder: (context) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(product == null ? 'افزودن کالا' : 'ویرایش کالا'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(controller: name, decoration: const InputDecoration(labelText: 'نام کالا'), validator: (v) => v == null || v.trim().isEmpty ? 'نام کالا را وارد کن.' : null),
                const SizedBox(height: 12),
                TextFormField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت واحد (تومان)'), validator: (v) => parseInt(v) == null || parseInt(v)! < 0 ? 'قیمت معتبر وارد کن.' : null),
                const SizedBox(height: 12),
                TextFormField(controller: purchase, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'تعداد خرید'), validator: (v) => parseInt(v) == null || parseInt(v)! < 0 ? 'تعداد معتبر وارد کن.' : null),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(
            onPressed: () {
              if (!formKey.currentState!.validate()) return;
              final p = Product(
                id: product?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
                name: name.text.trim(),
                unitPrice: parseInt(price.text)!,
                purchaseQty: parseInt(purchase.text)!,
                sales: product?.sales,
              );
              Navigator.pop(context, p);
            },
            child: const Text('ذخیره'),
          ),
        ],
      ),
    ),
  );
  name.dispose();
  price.dispose();
  purchase.dispose();
  return result;
}

int? parseInt(String? raw) {
  if (raw == null) return null;
  final s = normalizeDigits(raw).replaceAll(',', '').trim();
  if (s.isEmpty) return null;
  return int.tryParse(s);
}

Future<String?> showDateInputDialog(BuildContext context, {required String title}) async {
  final direct = TextEditingController();
  final month = TextEditingController();
  final day = TextEditingController();
  final formKey = GlobalKey<FormState>();

  final result = await showDialog<String>(
    context: context,
    builder: (context) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(title),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: direct,
                keyboardType: TextInputType.datetime,
                decoration: const InputDecoration(labelText: 'ورود مستقیم (مثلاً ۷.۵)'),
                validator: (v) => v == null || parseDate(v) == null ? 'تاریخ را به شکل ماه.روز وارد کن.' : null,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('یا انتخاب کن')), Expanded(child: Divider())]),
              ),
              Row(
                children: [
                  Expanded(child: TextFormField(controller: month, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ماه'))),
                  const SizedBox(width: 10),
                  Expanded(child: TextFormField(controller: day, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'روز'))),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(
            onPressed: () {
              final directDate = parseDate(direct.text);
              if (directDate != null) {
                Navigator.pop(context, '${directDate.$1}.${directDate.$2}');
                return;
              }
              final m = parseInt(month.text);
              final d = parseInt(day.text);
              if (m == null || d == null || m < 1 || m > 12 || d < 1 || d > 31) {
                showSnack(context, 'ماه و روز معتبر وارد کن.');
                return;
              }
              Navigator.pop(context, '$m.$d');
            },
            child: const Text('ثبت تاریخ'),
          ),
        ],
      ),
    ),
  );
  direct.dispose();
  month.dispose();
  day.dispose();
  return result;
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmText,
}) async {
  return await showDialog<bool>(
        context: context,
        builder: (context) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text(title),
            content: Text(message),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(confirmText)),
            ],
          ),
        ),
      ) ??
      false;
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}
